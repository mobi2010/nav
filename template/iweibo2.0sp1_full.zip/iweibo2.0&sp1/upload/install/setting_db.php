<?php
/**
 * 数据库配置文件
 */

return array(
	'dbHost' => '192.168.1.100:3306',
	'dbUser' => 'root',
	'dbPwd' => 'root',
	'dbCharset' => 'utf8',	//no use
	'dbPrefix' => 'iweibo2_',
	'dbName' => 'iweibo2_beta',
	'mysqli' => false,
	'dbPconnect' => false,
	'extConfig' => array(),
);
