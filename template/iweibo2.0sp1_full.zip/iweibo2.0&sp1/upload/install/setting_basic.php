<?php
 /**
 Cachefile auto created by IWeibo , created on GMT+8 2011-05-26 16:53:05 , do not modify it!
*/
return array (
  'rundebug' => '1',
  'cookiepre' => 't_',
  'cookiedomain' => '',
  'cookietime' => '30',
  'timezone' => '8',
  'rundubug' => '0',
  'resource_path' => '/',
  'site_open' => '0',
  'wap_on' => '1',
  'login_local' => '1',
  'login_tencent' => '1',
  'login_allow_new_user' => '1',
  'msg_showtime' => '3',
  'site_closed' => '0',
  'seo' => '0',
  'page_size' => '20',
  'sec_on' => '0',
  'censor' => '0',
  'site_name' => 'iWeibo2.0',
  'site_close_prompt' => '系统维护中，请稍候......',
  'site_tj' => '',
  'site_logo' => '/resource/images/iweibo.png',
);
