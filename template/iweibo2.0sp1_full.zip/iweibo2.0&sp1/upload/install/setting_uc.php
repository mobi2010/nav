<?php
 /**
 Cachefile auto created by IWeibo , created on GMT+8 2011-06-09 07:50:24 , do not modify it!
*/ 
return array (
  'connect' => 'mysql',
  'dbhost' => 'localhost',
  'dbuser' => 'root',
  'dbpw' => '258369',
  'dbname' => 'ucenter',
  'dbcharset' => 'utf8',
  'dbtablepre' => '`ucenter`.uc_',
  'dbconnect' => '0',
  'key' => '123456',
  'api' => 'http://ucenter',
  'charset' => 'utf-8',
  'ip' => '',
  'appid' => '3',
);
