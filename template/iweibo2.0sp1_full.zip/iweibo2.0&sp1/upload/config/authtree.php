<?php
return array(
	'user'  => array(),
	'admin' => array('a001' => '登录后台')
);